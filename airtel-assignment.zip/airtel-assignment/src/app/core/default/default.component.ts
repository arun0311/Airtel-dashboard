import { Component, OnInit, OnChanges } from '@angular/core';
import { Router } from '@angular/router'
import { NgxSpinnerService } from "ngx-spinner"; 

@Component({
  selector: 'app-default-page',
  templateUrl: './default.component.html',
})
export class DefaultComponent implements OnInit, OnChanges {
  
  public isLogin: any = JSON.parse(localStorage.getItem('isLogin'));

  constructor(private route: Router, private spinner: NgxSpinnerService) {
    
  }

  ngOnInit() {
    if(!this.isLogin) {
      this.route.navigate(['/login']);
      return;
    }
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);
  }
  ngOnChanges() {
    this.isLogin = JSON.parse(localStorage.getItem('isLogin'));
  }
}
