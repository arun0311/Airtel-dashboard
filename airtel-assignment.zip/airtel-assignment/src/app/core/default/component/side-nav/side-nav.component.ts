import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'side-nav',
  templateUrl: './side-nav.component.html',
})
export class SideNavComponent implements OnInit {

  public selectedOption: any = '';
  constructor(private route: Router) {}

  ngOnInit(): void {
    if(this.route.url.includes('dashboard')) {
      this.selectedOption = 'dashboard';
    }
  }

  /**
   * @method setActiveBtn
   */
  public setActiveBtn(option) {
    this.selectedOption = option;
  }
}
