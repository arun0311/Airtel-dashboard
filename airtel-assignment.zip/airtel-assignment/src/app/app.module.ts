import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './view/login/component/login.component';
import {
  MatCardModule,
  MatInputModule,
  MatButtonModule,
  MatSelectModule
} from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DashboardComponent } from './view/dashboard/component/dashboard.component';
import { HeaderComponent } from './core/default/component/header/header.component';
import { SideNavComponent } from './core/default/component/side-nav/side-nav.component';
import { DefaultComponent } from './core/default/default.component';
import { FooterComponent } from './core/default/component/footer/footer.component';
import { ImageViewerModule } from 'ng2-image-viewer';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HelpComponent } from './view/help/component/help.component';
import { ProfileComponent } from './view/profile/component/profilecomponent';
import { SettingComponent } from './view/setting/component/setting.component';
import { NgxSpinnerModule } from "ngx-spinner"; 

const modules = [
  MatCardModule,
  MatInputModule,
  MatButtonModule,
  MatSelectModule
];

@NgModule({
  declarations: [
    AppComponent,
    DefaultComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    SideNavComponent,
    FooterComponent,
    HelpComponent,
    ProfileComponent,
    SettingComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    ImageViewerModule,
    NgbModule,
    NgxSpinnerModule,
    modules
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
