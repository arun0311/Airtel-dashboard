import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DashboardService } from '../service/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit {

  public userDetailForm: FormGroup;
  public formControls: any;
  public imageSource: any;
  public isFormEditable: boolean = false;

  constructor(
    private fb: FormBuilder /* inject to build a form*/,
    private sanitizer: DomSanitizer /* inject to read base64 type image*/,
    private dashboardService: DashboardService /* inject dashboardService for dependency  */,
    ) {}

  /* method that is invoked immediately after constructor */  
  ngOnInit () {
    this.initializeForm();
    this.getSubscriberDetails('87867867876');
    // let image = 'null';
    // this.imageSource = this.sanitizer.bypassSecurityTrustResourceUrl(`data:image/png;base64, ${image}`);
  }

  /**
   * create user detail form filds
   * @method initializeForm
   */
  public initializeForm() {
    this.userDetailForm = this.fb.group({
      IDType: ['', [Validators.required]],
      IDNumber: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      dob: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      emailID: [' '],
      alternateNo: ['', [Validators.required]],
      state: ['', [Validators.required]],
      district: ['', [Validators.required]],
      lga: ['', [Validators.required]],
      city: ['', [Validators.required]],
      addressLine1: ['', [Validators.required]],
      addressLine2: ['', [Validators.required]],
      addressLine3: ['', [Validators.required]],
      postalCode: ['', [Validators.required]],
    });
    this.formControls = this.userDetailForm.controls; /* formControls of user details form*/
  }

  /**
   * gets information of subscriber
   * @method getSubscriberDetails
   */
  public getSubscriberDetails(userMobile) {
    
    /* Call api to get customer data and fill form details*/
    let response = this.dashboardService.getCustomerData(userMobile)
    this.fillDataToForm(response);
  }

  /**
   * populate the user details in form
   * @method fillDataToForm
   */
  public fillDataToForm(response) {
    console.log();
    
    this.userDetailForm.patchValue(response);
  }

  /**
   * @method onCardClick
   */
  public onCardClick() {
    
  }

  /**
   * gets updated subscriber details
   * @method refreshSubscriberDetails
   */
  public refreshSubscriberDetails() {
    /* Call api to get resent case and update details*/

  }

  /**
   * submits the form with updated details
   * @method onSubmit
   */
  public onSubmit() {
    
  }

  /**
   * make user form fields editable
   * @method editUserDetails
   */
  public editUserDetails() {
    this.isFormEditable = true;
  }
}
