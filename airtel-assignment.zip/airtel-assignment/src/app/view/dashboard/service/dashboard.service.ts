import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor() { }

  /**
   * gets customer data
   * @method getCustomerData
   */
  public getCustomerData(mobile) {

    /*get request with customer mobile number*/
    let response;
    if (mobile) {
      response = {
        IDType: 'Passport',
        IDNumber: '83749384934',
        firstName: 'Doe',
        dob: '22-08-1989',
        gender: 'M',
        emailID: ' ',
        alternateNo: '9897657865',
        state: 'zambezi',
        district: 'lusaka',
        lga: 'federal',
        city: 'pemba',
        addressLine1: 'B-25/44',
        addressLine2: 'Near Airtel Office',
        addressLine3: 'Hudson road',
        postalCode: '101010',
      }
    } else {
      response = '';
    }
    return response;
  }
}
